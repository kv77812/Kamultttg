/* ======================================================================
   render.js  -  turns index.html into an MP4 (picture + voice over + music)

   How it works (frame-perfect, no screen recording):
   1. Serves this folder on a local web server.
   2. Opens index.html?render=1 in headless Chrome at phone size
      (360 x 640 CSS px  x  scale 3  =  1080 x 1920 video, 9:16, fills an Android phone).
   3. Freezes Chrome's clock ("virtual time") and moves it forward exactly
      1/30 s at a time, taking a screenshot after every step.
      Every zoom, fade and text animation therefore lands on the exact frame.
   4. ffmpeg joins the frames with Assets/voiceover.mp3 and the instrumental
      (music at 16 % volume, fading out over the last 3 s) into one MP4.

   Output:  output/kalmutttg-advert.mp4   (also copied to video.mp4)

   Optional environment variables (defaults in brackets):
     VIDEO_WIDTH [360]  VIDEO_HEIGHT [640]  VIDEO_SCALE [3]  FPS [30]  DURATION [60]
   ====================================================================== */

const fs = require("fs");
const path = require("path");
const http = require("http");
const { spawnSync } = require("child_process");
const puppeteer = require("puppeteer");

const ROOT = __dirname;
const W = parseInt(process.env.VIDEO_WIDTH || "360", 10);
const H = parseInt(process.env.VIDEO_HEIGHT || "640", 10);
const SCALE = parseFloat(process.env.VIDEO_SCALE || "3");
const FPS = parseInt(process.env.FPS || "30", 10);
const DURATION = parseFloat(process.env.DURATION || "60");
const TOTAL_FRAMES = Math.round(DURATION * FPS);

const FRAMES_DIR = path.join(ROOT, "frames");
const OUT_DIR = path.join(ROOT, "output");
const OUT_FILE = path.join(OUT_DIR, "kalmutttg-advert.mp4");

const log = (...a) => console.log(...a);

/* ---------- ffmpeg: system one first, bundled one as fallback ---------- */
function findFfmpeg() {
    const sys = spawnSync("ffmpeg", ["-version"], { encoding: "utf8" });
    if (sys.status === 0) return "ffmpeg";
    try {
        const p = require("ffmpeg-static");
        if (p && fs.existsSync(p)) return p;
    } catch (e) {}
    throw new Error("ffmpeg not found. Install ffmpeg or run: npm install ffmpeg-static");
}

/* ---------- tiny static file server (so Assets/ loads exactly as on the web) ---------- */
const MIME = {
    ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css",
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
    ".mp3": "audio/mpeg", ".json": "application/json"
};
function startServer() {
    return new Promise(resolve => {
        const server = http.createServer((req, res) => {
            let rel = decodeURIComponent(req.url.split("?")[0]);
            if (rel === "/") rel = "/index.html";
            const file = path.join(ROOT, rel);
            if (!file.startsWith(ROOT) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
                res.writeHead(404); res.end("not found"); return;
            }
            res.writeHead(200, { "Content-Type": MIME[path.extname(file).toLowerCase()] || "application/octet-stream" });
            fs.createReadStream(file).pipe(res);
        });
        server.listen(0, "127.0.0.1", () => resolve(server));
    });
}

/* ---------- helpers ---------- */
function waitForEvent(client, name) {
    return new Promise(resolve => client.once(name, resolve));
}

async function launchBrowser() {
    const args = [
        "--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage",
        "--hide-scrollbars", "--force-color-profile=srgb", "--font-render-hinting=none",
        "--disable-lcd-text", "--mute-audio"
    ];
    try {
        return await puppeteer.launch({ headless: "shell", args });
    } catch (e) {
        log("headless-shell not available, using standard headless Chrome:", e.message);
        return await puppeteer.launch({ headless: true, args });
    }
}

async function main() {
    const ffmpeg = findFfmpeg();
    log("ffmpeg:", ffmpeg);

    for (const f of ["index.html", "Assets/voiceover.mp3", "Assets/still-dre-instrumental.mp3"]) {
        if (!fs.existsSync(path.join(ROOT, f))) throw new Error("Missing required file: " + f);
    }

    fs.rmSync(FRAMES_DIR, { recursive: true, force: true });
    fs.mkdirSync(FRAMES_DIR, { recursive: true });
    fs.mkdirSync(OUT_DIR, { recursive: true });

    const server = await startServer();
    const port = server.address().port;
    const browser = await launchBrowser();

    try {
        const page = await browser.newPage();
        await page.setViewport({ width: W, height: H, deviceScaleFactor: SCALE, isMobile: true, hasTouch: true });

        page.on("pageerror", e => log("PAGE ERROR:", e.message));
        page.on("requestfailed", r => {
            if (!/\.mp3/.test(r.url())) log("REQUEST FAILED:", r.url());
        });

        // Sound is added by ffmpeg, so the page does not need to download the mp3 files.
        await page.setRequestInterception(true);
        page.on("request", req => (/\.mp3(\?|$)/.test(req.url()) ? req.abort() : req.continue()));

        await page.goto(`http://127.0.0.1:${port}/index.html?render=1`, { waitUntil: "load" });
        await page.waitForFunction("window.__assetsReady === true", { timeout: 60000 });
        log("Page loaded, all images ready.");

        const client = await page.createCDPSession();

        // Freeze the clock, start the advert at virtual time zero.
        await client.send("Emulation.setVirtualTimePolicy", { policy: "pause" });
        await page.evaluate("window.__startRender()");

        const step = 1000 / FPS;
        const t0 = Date.now();

        for (let i = 0; i < TOTAL_FRAMES; i++) {
            const expired = waitForEvent(client, "Emulation.virtualTimeBudgetExpired");
            await client.send("Emulation.setVirtualTimePolicy", {
                policy: "pauseIfNetworkFetchesPending",
                budget: step
            });
            await expired;

            const shot = await client.send("Page.captureScreenshot", {
                format: "jpeg", quality: 92, optimizeForSpeed: true
            });
            const name = path.join(FRAMES_DIR, String(i).padStart(5, "0") + ".jpg");
            fs.writeFileSync(name, Buffer.from(shot.data, "base64"));

            if (i % 90 === 0 || i === TOTAL_FRAMES - 1) {
                const secs = ((Date.now() - t0) / 1000).toFixed(0);
                log(`frame ${i + 1}/${TOTAL_FRAMES}  (video time ${(i / FPS).toFixed(1)}s, elapsed ${secs}s)`);
            }
        }
    } finally {
        await browser.close().catch(() => {});
        server.close();
    }

    /* ---------- join picture + sound ---------- */
    log("Encoding MP4 ...");
    const fadeStart = Math.max(0, DURATION - 3);
    const filter =
        `[1:a]atrim=0:${DURATION},asetpts=PTS-STARTPTS,apad=whole_dur=${DURATION}[vo];` +
        `[2:a]atrim=0:${DURATION},asetpts=PTS-STARTPTS,volume=0.16,afade=t=out:st=${fadeStart}:d=3[mu];` +
        `[vo][mu]amix=inputs=2:duration=first:dropout_transition=0,volume=2,atrim=0:${DURATION}[a];` +
        `[0:v]scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p[v]`;

    const args = [
        "-y",
        "-framerate", String(FPS), "-i", path.join(FRAMES_DIR, "%05d.jpg"),
        "-i", path.join(ROOT, "Assets", "voiceover.mp3"),
        "-i", path.join(ROOT, "Assets", "still-dre-instrumental.mp3"),
        "-filter_complex", filter,
        "-map", "[v]", "-map", "[a]",
        "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-profile:v", "high", "-level", "4.1",
        "-r", String(FPS),
        "-c:a", "aac", "-b:a", "192k", "-ar", "44100",
        "-movflags", "+faststart",
        "-t", String(DURATION),
        OUT_FILE
    ];
    const r = spawnSync(ffmpeg, args, { stdio: "inherit" });
    if (r.status !== 0) throw new Error("ffmpeg failed with exit code " + r.status);

    fs.copyFileSync(OUT_FILE, path.join(ROOT, "video.mp4"));
    if (!process.env.KEEP_FRAMES) fs.rmSync(FRAMES_DIR, { recursive: true, force: true });

    const mb = (fs.statSync(OUT_FILE).size / 1048576).toFixed(1);
    log(`\nDONE: ${OUT_FILE}  (${mb} MB)`);
}

main().catch(err => {
    console.error("RENDER FAILED:", err);
    process.exit(1);
});
