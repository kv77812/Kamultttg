@echo off
set VERSION=8.9
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
set DIST=%USERPROFILE%\.gradle\wrapper\dists\gradle-%VERSION%-bin
set ZIP=%DIST%\gradle-%VERSION%-bin.zip
set INSTALL=%DIST%\gradle-%VERSION%
if not exist "%INSTALL%\bin\gradle.bat" (
  if not exist "%DIST%" mkdir "%DIST%"
  if not exist "%ZIP%" powershell -NoProfile -Command "Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%ZIP%'"
  powershell -NoProfile -Command "Expand-Archive -Force '%ZIP%' '%DIST%'"
)
call "%INSTALL%\bin\gradle.bat" %*
