#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

: "${VIDEO_WIDTH:=1080}"
: "${VIDEO_HEIGHT:=1920}"
FPS=30
TOTAL=60
FONT="/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
OUT_DIR="$ROOT/output"
SCENE_DIR="$OUT_DIR/scenes"
FINAL="$OUT_DIR/KALMUTTTG_60sec.mp4"

command -v ffmpeg >/dev/null || { echo "FFmpeg is required." >&2; exit 1; }
command -v ffprobe >/dev/null || { echo "FFprobe is required." >&2; exit 1; }
[[ -f "$FONT" ]] || FONT="/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf"

rm -rf "$SCENE_DIR"
mkdir -p "$SCENE_DIR"

# duration|image|title|description|motion seed
render_scene() {
  local n="$1" dur="$2" img="$3" title="$4" desc="$5" zoom="$6"
  local out="$SCENE_DIR/scene_${n}.mp4"

  ffmpeg -y -hide_banner -loglevel error \
    -loop 1 -t "$dur" -i "$img" \
    -vf "fps=${FPS},scale=${VIDEO_WIDTH}:${VIDEO_HEIGHT}:force_original_aspect_ratio=increase,crop=${VIDEO_WIDTH}:${VIDEO_HEIGHT},fade=t=in:st=0:d=0.65,fade=t=out:st=$(awk "BEGIN{print $dur-0.65}"):d=0.65,drawbox=x=0:y=0:w=iw:h=ih:color=black@0.30:t=fill,drawtext=fontfile='${FONT}':text='KALMUTTTG (PVT) LTD':fontcolor=white:fontsize=68:borderw=3:bordercolor=black@0.85:x=(w-text_w)/2:y=h*0.27,drawtext=fontfile='${FONT}':text='${title}':fontcolor=white:fontsize=50:borderw=3:bordercolor=black@0.85:x=(w-text_w)/2:y=h*0.40,drawtext=fontfile='${FONT}':text='${desc}':fontcolor=white:fontsize=30:borderw=2:bordercolor=black@0.85:x=(w-text_w)/2:y=h*0.49:enable='between(t,0.2,$(awk "BEGIN{print $dur-0.2}"))'" \
    -an -c:v libx264 -preset medium -crf 20 -pix_fmt yuv420p -movflags +faststart "$out"
}

# Text is kept short enough to remain legible on portrait and landscape outputs.
render_scene 1 8  "Assets/vegetation.png"       "Providing solar and electrical solutions" "For industrial and domestic uses." 1.08
render_scene 2 10 "Assets/solar-panels.jpg"      "SOLAR POWER SOLUTIONS"               "Practical solar power solutions for homes and businesses." 1.12
render_scene 3 10 "Assets/vegetation.png"         "RELIABLE POWER"                      "Energy solutions designed to keep essential power running." 1.10
render_scene 4 10 "Assets/electrical-tubing.jpg"  "ELECTRICAL INSTALLATIONS"            "Professional electrical solutions for domestic and industrial environments." 1.13
render_scene 5 10 "Assets/electrical-fencing.jpg" "ELECTRICAL FENCING"                   "Security-focused solutions for homes, businesses and properties." 1.10
render_scene 6 7  "Assets/aircon.jpg"             "TECHNICAL SOLUTIONS"                 "Reliable electrical and technical solutions designed around your needs." 1.12
render_scene 7 5  "Assets/vegetation.png"         "GO GREEN. POWER SMART."              "Choose KALMUTTTG for solar and electrical solutions." 1.08

cat > "$SCENE_DIR/concat.txt" <<EOT
file 'scene_1.mp4'
file 'scene_2.mp4'
file 'scene_3.mp4'
file 'scene_4.mp4'
file 'scene_5.mp4'
file 'scene_6.mp4'
file 'scene_7.mp4'
EOT

ffmpeg -y -hide_banner -loglevel error \
  -f concat -safe 0 -i "$SCENE_DIR/concat.txt" \
  -c copy -movflags +faststart "$SCENE_DIR/video_only.mp4"

# Add the supplied logo to the opening scene area and mix the supplied voice-over
# with the supplied instrumental. The music is deliberately kept underneath narration.
ffmpeg -y -hide_banner -loglevel error \
  -i "$SCENE_DIR/video_only.mp4" \
  -loop 1 -t "$TOTAL" -i "Assets/logo.jpg" \
  -i "Assets/voiceover.mp3" \
  -stream_loop -1 -i "Assets/still-dre-instrumental.mp3" \
  -filter_complex "\
    [1:v]scale=220:220:force_original_aspect_ratio=decrease,format=rgba,colorchannelmixer=aa=0.96[logo];\
    [0:v][logo]overlay=x=(W-w)/2:y=H*0.12:enable='between(t,0,8)':format=auto[v];\
    [2:a]atrim=0:${TOTAL},asetpts=N/SR/TB,volume=1.0[voice];\
    [3:a]atrim=0:${TOTAL},asetpts=N/SR/TB,volume=0.16[music];\
    [voice][music]amix=inputs=2:duration=first:dropout_transition=0,alimiter=limit=0.95[a]" \
  -map "[v]" -map "[a]" -t "$TOTAL" \
  -c:v libx264 -preset medium -crf 19 -pix_fmt yuv420p \
  -c:a aac -b:a 192k -ar 48000 -movflags +faststart "$FINAL"

DURATION=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$FINAL")
SIZE=$(du -h "$FINAL" | cut -f1)
echo "Rendered: $FINAL"
echo "Duration: ${DURATION}s"
echo "Size: ${SIZE}"
