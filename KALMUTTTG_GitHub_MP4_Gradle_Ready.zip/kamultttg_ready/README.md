# KALMUTTTG (PVT) LTD — MP4 Video Build

This repository converts the supplied KALMUTTTG promotional assets into a **60-second MP4** using FFmpeg, with the supplied voice-over and background instrumental mixed into the final video.

## GitHub Actions

Go to **Actions → Build KALMUTTTG MP4 Video → Run workflow**. The generated MP4 is uploaded as a workflow artifact named `KALMUTTTG-MP4`.

## Local build

Requirements: Java 17+ and FFmpeg 6+ (7+ recommended).

```bash
./gradlew buildVideo
```

Output: `output/KALMUTTTG_60sec.mp4`

The default format is portrait 1080×1920. Override if needed:

```bash
VIDEO_WIDTH=1920 VIDEO_HEIGHT=1080 ./gradlew buildVideo
```

## Audio

- `Assets/voiceover.mp3` is the primary narration and is normalized to the 60-second program.
- `Assets/still-dre-instrumental.mp3` is looped as necessary and mixed underneath the narration at a reduced level.
- The final mix is limited to avoid clipping.

## Important

The original browser version remains in `index.html`. The MP4 renderer does not depend on browser autoplay or HTML timing, so GitHub Actions can produce the video deterministically.

## Gradle wrapper

`gradlew` / `gradlew.bat` are included and pin the build to **Gradle 8.9**. On a machine with Gradle already installed they use it; otherwise the bootstrap downloads the pinned Gradle distribution. GitHub Actions also pins Gradle 8.9 through the official Gradle setup action.
