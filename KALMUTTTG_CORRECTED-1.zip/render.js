const fs = require('fs');
const path = require('path');
const http = require('http');
const { chromium } = require('playwright');
const { spawn } = require('child_process');

const ROOT = __dirname;
const OUTPUT = path.join(ROOT, 'output');
const BROWSER_DIR = path.join(OUTPUT, 'browser');
const FINAL = path.join(OUTPUT, 'KALMUTTTG_Final_Video.mp4');
const PORT = 4173;

function run(command, args) {
  return new Promise((resolve, reject) => {
    const p = spawn(command, args, { stdio: 'inherit' });
    p.on('error', reject);
    p.on('close', code => code === 0 ? resolve() : reject(new Error(`${command} exited with code ${code}`)));
  });
}

function startServer() {
  const server = http.createServer((req, res) => {
    let urlPath = decodeURIComponent((req.url || '/').split('?')[0]);
    if (urlPath === '/') urlPath = '/index.html';
    const file = path.resolve(ROOT, '.' + urlPath);
    if (!file.startsWith(ROOT + path.sep) && file !== ROOT) {
      res.writeHead(403); res.end('Forbidden'); return;
    }
    fs.stat(file, (err, stat) => {
      if (err || !stat.isFile()) { res.writeHead(404); res.end('Not found'); return; }
      const ext = path.extname(file).toLowerCase();
      const types = {
        '.html': 'text/html; charset=utf-8',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.png': 'image/png',
        '.mp3': 'audio/mpeg'
      };
      res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' });
      fs.createReadStream(file).pipe(res);
    });
  });
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(PORT, '127.0.0.1', () => resolve(server));
  });
}

(async () => {
  fs.rmSync(OUTPUT, { recursive: true, force: true });
  fs.mkdirSync(BROWSER_DIR, { recursive: true });

  const server = await startServer();
  let browser;
  try {
    browser = await chromium.launch({
      headless: true,
      args: [
        '--autoplay-policy=no-user-gesture-required',
        '--disable-background-timer-throttling',
        '--disable-backgrounding-occluded-windows',
        '--disable-renderer-backgrounding'
      ]
    });

    const context = await browser.newContext({
      viewport: { width: 1280, height: 720 },
      deviceScaleFactor: 1,
      recordVideo: {
        dir: BROWSER_DIR,
        size: { width: 1280, height: 720 }
      }
    });

    const page = await context.newPage();
    page.on('console', msg => console.log(`[browser] ${msg.type()}: ${msg.text()}`));
    page.on('pageerror', err => console.error('[browser pageerror]', err));

    console.log('Opening KALMUTTTG advertisement...');
    await page.goto(`http://127.0.0.1:${PORT}/index.html`, { waitUntil: 'networkidle' });
    await page.waitForFunction(() => document.readyState === 'complete');

    console.log('Rendering full 60-second timeline...');
    await page.waitForTimeout(62000);

    await context.close();
    await browser.close();
    browser = null;

    const webmFiles = fs.readdirSync(BROWSER_DIR)
      .filter(f => f.toLowerCase().endsWith('.webm'))
      .map(f => path.join(BROWSER_DIR, f));
    if (webmFiles.length !== 1) throw new Error(`Expected exactly one browser recording, found ${webmFiles.length}`);

    const webm = webmFiles[0];
    const voice = path.join(ROOT, 'Assets', 'voiceover.mp3');
    const music = path.join(ROOT, 'Assets', 'still-dre-instrumental.mp3');

    for (const f of [voice, music]) {
      if (!fs.existsSync(f)) throw new Error(`Missing audio file: ${f}`);
    }

    console.log('Encoding final 60-second MP4 with voiceover + instrumental...');
    await run('ffmpeg', [
      '-y',
      '-i', webm,
      '-i', voice,
      '-i', music,
      '-filter_complex',
      '[1:a]volume=1.0[voice];[2:a]volume=0.16[music];[voice][music]amix=inputs=2:duration=longest:dropout_transition=0[a]',
      '-map', '0:v:0',
      '-map', '[a]',
      '-t', '60',
      '-c:v', 'libx264',
      '-preset', 'medium',
      '-crf', '18',
      '-pix_fmt', 'yuv420p',
      '-r', '30',
      '-c:a', 'aac',
      '-b:a', '192k',
      '-movflags', '+faststart',
      FINAL
    ]);

    console.log(`FINAL VIDEO: ${FINAL}`);
  } finally {
    if (browser) await browser.close().catch(() => {});
    server.close();
  }
})().catch(err => {
  console.error(err.stack || err);
  process.exit(1);
});
